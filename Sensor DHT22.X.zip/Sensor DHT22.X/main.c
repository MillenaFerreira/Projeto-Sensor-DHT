#include "config.h"
#include <xc.h>
#include "delay.h"
#include "lcd.h"
#include "teclado.h"
#include "editnum.h"
#include "dht.h"

DHT_t sensor; //DHT_t � a forma, o que vem depois � o lugar que vai colocar




void main( void )
{
    unsigned char fases = 0;
    unsigned long tu;
    unsigned long checksum;
    int num = 0;
    char tecla = 0;
    delay(2000);
    lcd_init();
    teclado_init();
    dht_init();
    lcd_print(0,0,"Iniciando");
    delay(2000);
    
    
    while( 1 )
    {   
        dht_showread( &sensor );
        tecla = teclado();
        edit( &num, tecla, '*', '-', 0, 20000  ); 
        lcd_num(0, 11, num, 5);
              
        switch( fases )
        {
            case 0:      
                   lcd_print(0,0,"Menu        ");
                   tu = dht_comunic();                  
                   lcd_num(1,0, (int)(tu >>16) , 3);
                   lcd_print(1,3,"PH%");
                   lcd_num(1,8, (int)(tu &0x0000FFFF) , 3);
                   lcd_print(1,11,"C");
                   fases=1;
                                 
            case 1:
                switch( num )
                                 {  
                                     delay(2500);
                                     lcd_numhidden(0, 11, num, 5);
                                     case 8:   num=0;  fases=10; break;
                                     case 777: num=0;  fases=20; break;
                                     case 500: num=0; lcd_print(1,0,"                ");  fases=30; break;
                                 }
                break;       
            
            case 10:  
                    lcd_print(1,0,"Nova leitura");
                    delay(1000);
                    lcd_print(1,0,"                ");
         
                    tu = dht_comunic();
                    lcd_num(1,0, (int)(tu >>16) , 3);
                    lcd_print(1,3,"PH%");
                    lcd_num(1,8, (int)(tu &0x0000FFFF) , 3);
                    lcd_print(1,11,"C");
                    
                    fases=1;
                    break;
            
            case 20:
                    lcd_print(0,0,"TELA AZUL");delay(500);lcd_print(1,0,"TRAAVOOUUUUU");delay(500);
                    lcd_print(1,0,"HEHEHHAHAHAH");delay(500);lcd_print(0,0,"JASHIN");delay(500);fases=20; 
                    break;
           
            case 30:
                ///////////////Menu Sensor DHT
                    
                    lcd_print(0,0,"Sensor DHT");
               
                    
                    if (num==91) fases=31;
                    if (num==92) fases=31;
                    if (num==93) fases=31;
                    if (num==94) fases=31;
                    break;
                    
                                case 31:      
                                        switch( num )
                                        {
                                            case 91: num= 0;  fases=32; break;
                                            case 92: num= 0;  fases=33; break;
                                            case 93: num= 0;  fases=34; break;
                                            case 94: num= 0;  fases=35; break;
                                        }
                                        break;
            
            case 32:   
                    lcd_print(1,0,"Voltando Menu ");
                    lcd_print(0,0,"                ");
                    delay(1000);
                    fases=1;
                    break;    
            case 33: 
                    lcd_num(1,8, (int)(tu &0x0000FFFF) , 3);
                    lcd_print(1,11,"C");
                    fases=30;
                    break;
                   
            case 34:
                    lcd_num(1,0, (int)(tu >>16) , 3);
                    lcd_print(1,3,"PH%");
                    fases=30;
                    break;   
                    
            case 35:
                    while(num!=9)
                    {
                        tu = dht_comunic();                  
                        lcd_num(1,0, (int)(tu >>16) , 3);
                        lcd_print(1,3,"PH%");
                        lcd_num(1,8, (int)(tu &0x0000FFFF) , 3);
                        lcd_print(1,11,"C");
                        delay(5000);
                    }
                    fases=31;          
                    break;           
        }
    }        
}
