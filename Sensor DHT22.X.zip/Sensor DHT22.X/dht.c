/*
 * File:   dht.c
 * Author: 20184318
 *
 * Created on 21 de Mar�o de 2022, 11:05
 */

#include <xc.h>
#include "dht.h"
#include "delay.h"

#define DHT_PIN PORTCbits.RC0
#define DHT_IN  TRISCbits.TRISC0 = 1
#define DHT_OUT TRISCbits.TRISC0 = 0

#define DHT_TEST    PORTAbits.RA0

void dht_init( void )
{
    DHT_OUT;
    DHT_PIN = 1;
    ANSEL = 0;
    TRISAbits.TRISA0 = 0;
    DHT_TEST = 0;
}

void dht_showread ( DHT_t * ptr ) // Serve para mostrar no lcd para for�ar uma leitura coloque um "= numero" 
{
    ptr->dht.temperatu;
    ptr->dht.tempefra;
    ptr->dht.umida;
    ptr->dht.umidafra; 
}

char pin_anteiror=0;
char bordapin( void )
{
    // pin: 000000000001111111111111100000000
    // ret: 000000000001000000000000000000000
    char aux;
    aux = DHT_PIN && !pin_anteiror;
    pin_anteiror = DHT_PIN;
    return( aux );
}

unsigned long tu =0;
unsigned char contbits =0;
unsigned long checksum=0;
unsigned long dht_comunic (void)
{
    
    DHT_TEST = 1;
    //////////////////////////////
    DHT_OUT;
    DHT_PIN=0;
    __delay_ms(1);                 //////////// inicia a leitura
    DHT_PIN=1;
    __delay_us(40);
    DHT_IN;
   ////////////////////////////////
    DHT_TEST = 0;
    contbits = 0;
    while( DHT_PIN )
        ;
    DHT_TEST = 1;
    while( !DHT_PIN )
        ;
    DHT_TEST = 0;
    
    while( DHT_PIN )
        ;

    while (contbits<40)
    {
        DHT_TEST = 0;
        while( !DHT_PIN )
            ;
        DHT_TEST = 1;
        __delay_us(40);
        
        if( contbits<32 )
        {  
            tu  = tu << 1;
            tu += DHT_PIN ? 1 : 0;
            
        }
        else
        {
            checksum = checksum << 1;
            checksum += DHT_PIN ? 1 : 0;
           
        }

        while( DHT_PIN )
            ;
        contbits++;
       
    }
        
//        if( DHT_PIN && !pin_anteiror )
//        {  
//            DHT_TEST = 1;
//            __delay_us(20);
//            if( contbits<32 )
//            {  
//                tu  = tu << 1;
//                tu += DHT_PIN ? 1 : 0;
////                if(DHT_PIN)
////                  tu++;
//            }
//            else
//            {
//                checksum = checksum << 1;
//                checksum += DHT_PIN ? 1 : 0;
////                if(DHT_PIN)
////                   checksum++;
//            }
//            contbits++;
//        }
//        pin_anteiror = DHT_PIN;
//    }
    return(tu);
}