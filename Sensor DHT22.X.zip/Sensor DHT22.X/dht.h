/* 
 * File:   dht.h
 * Author: 20184318
 *
 * Created on 21 de Mar�o de 2022, 11:24
 */

#ifndef DHT_H
#define	DHT_H

typedef union
{
    struct
    {
        unsigned char umidafra;
        unsigned char umida;
        unsigned char tempefra;
        unsigned char temperatu;
    } dht;
    unsigned long bits;
} DHT_t;

void test(void);

void dht_init( void );

void dht_showread (DHT_t* ptr);

void dht_forceread (DHT_t* ptr);

unsigned long dht_comunic ( void );

char bordapin( void );

#endif	/* DHT_H */

