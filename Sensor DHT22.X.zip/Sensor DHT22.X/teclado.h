#ifndef TECLADO_H
#define TECLADO_H

void teclado_init( void );
unsigned char teclado( void );

#endif
