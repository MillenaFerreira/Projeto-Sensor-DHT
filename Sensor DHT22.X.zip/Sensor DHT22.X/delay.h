#ifndef DELAY_H
#define DELAY_H

#define _XTAL_FREQ  20000000

void delay( unsigned int t );
void delaydht( unsigned int t );
#endif
