#ifndef EDITNUM_H
#define EDITNUM_H

void edit(  int * ptr_edit, 
            unsigned char tecla, 
            unsigned char delete,
            unsigned char menos,
            unsigned int min,
            unsigned int max );



#endif
